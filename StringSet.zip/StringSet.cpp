#include "StringSet.h"

StringSet::StringSet()
{
    //ekki nau�synlegt ef Constructorinn er ekki skilgreindur inni � .h
}

/* addToVector
 * Athugar hvort or� s� til � vectornum
 * svo �a� komi ekki fyrir tvisvar � vectornum.
 * (svo �nnur f�ll skrifi ekki �t tvisvar or�i� t.d.)
 */
void StringSet::addToVector(string aWord)
{
    for (size_t i = 0; i < listOfWords.size(); i++)
    {
        if (listOfWords[i] == aWord)
        return;
    }
    listOfWords.push_back(aWord);
}

/* at
 * Skilar or�i � sta�setningunni "i".
 */
string StringSet::at (int i) const
{
    return listOfWords[i];
}

/* size
 * Skilar st�r� � vectornum "listOfWords"
 */
unsigned int StringSet::size() const
{
    return listOfWords.size();
}

/* find
 * Leitar a� or�i � vectornum listOfWords
 * � sta�setningunni "i" og skilar �� true, annars false.
 */
bool StringSet::find(string aWord)
{
    for (size_t i = 0; i < listOfWords.size(); i++)
    {
        if (listOfWords[i] == aWord)
        {
            return true;
        }
    }
    return false;
}

/* operator <<
 * B�r til virkni fyrir operatorinn "<<" inni � cout
 * og prentar �t �r vectornum "listOfWords" me�
 * tilv�suninni doc1 � klasann StringSet.
 */
ostream& operator << (ostream& out, const StringSet& s)
{
    for (size_t i = 0; i < s.size(); i++)
    {
        out << s.at(i) + " ";
    }
 return out;
}

/* operator +
 * B�r til virkni fyrir operatorinn "+"
 * og n�tir s�r duplicate checki� �r "addToVector"
 * og tekur or� sem koma �v� bara fyrir � ��rum hvorum
 * vectornum en ekki b��um og setur saman � n�jan vector.
 */
StringSet operator + (const StringSet& left, const StringSet& right)
{
    StringSet leftXorRight;

    for (size_t i = 0; i < left.size(); i++)
    {
        leftXorRight.addToVector(left.at(i));
    }

    for (size_t i = 0; i < right.size(); i++)
    {
        leftXorRight.addToVector(right.at(i));
    }

    return leftXorRight;
}

/* leftAndRight
 * Tekur or� sem koma fyrir � b��um vectorum
 * og skilar �eim fr� s�r � n�jum vector.
 */
StringSet operator * (const StringSet& left, const StringSet& right)
{
    StringSet leftAndRight;

    for (size_t i = 0; i < left.size(); i++)
    {
        for (size_t j = 0; j < right.size(); j++)
        {
            if (left.at(i) == right.at(j))
            {
                leftAndRight.addToVector(left.at(i));
            }
        }
    }
    return leftAndRight;
}
