#ifndef STRINGSET_H
#define STRINGSET_H
#include <string>
#include <vector>

using namespace std;

class StringSet
{
private:
    vector<string> listOfWords;

public:
    StringSet(); // ekki nau�synlegt (constructor)
    void addToVector(string fileWord);
    string at(int i) const;
    unsigned int size() const;
    bool find(string fileWord);

    friend ostream& operator << (ostream& out, const StringSet& s);
    friend StringSet operator + (const StringSet& left, const StringSet& right);
    friend StringSet operator * (const StringSet& left, const StringSet& right);
};

#endif // STRINGSET_H
