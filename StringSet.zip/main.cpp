#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include "StringSet.h"

using namespace std;

// The following functions are used
// within the main() function.
// You should implement those functions
// as well as the StringSet class.

void readFileKeywords(StringSet& setDocument, const char filename[]);
double similarity(const StringSet& set1, const StringSet& set2);

int main()
{
StringSet doc1;
StringSet doc2;
StringSet theUnion;
StringSet query;

    readFileKeywords(doc1, "doc1.txt");
    readFileKeywords(doc2, "doc2.txt");


    cout << "Doc1: " << doc1 << endl;
    cout << "Doc2: " << doc2 << endl;
    theUnion = doc1 + doc2;
    cout << "Union: " << theUnion << endl;

    readFileKeywords(query, "query.txt");
    cout << "Query: " << query << endl;

    int count = 0;

for (unsigned int i = 0; i < query.size(); i++)
{
    if (theUnion.find(query.at(i)))
    {
        count++;
    }
}

cout << "Query size: " << query.size() << endl;
cout << "Found in union: " << count << endl;

    // Calculate similarity to each document
double sim1 = similarity(doc1, query);
cout << "Similarity to doc1: " << sim1 << endl;

double sim2 = similarity(doc2, query);
cout << "Similarity to doc2: " << sim2 << endl;

return 0;
}

/* readFileKeywords
 * setDocument ver�ur fyrst a� doc1
 * �v� n�st a� svo doc2 en seinna a� query.
 */
void readFileKeywords(StringSet& setDocument, const char filename[])
{
    string fileWord;
    ifstream file;
    file.open(filename); //opnar skjal, ef engin sl�� er skilgreind, �� opnar h�n � r�tinni

    if(file.is_open())
    {
        while (file >> fileWord)
        {
            setDocument.addToVector(fileWord);
        }
        file.close();
    }
}

/* similarity
 * Athugar notar "query" skr�na
 * til a� bera hana saman vi� doc1 og doc2
 * og athugar l�kindin �ar � milli.
 */
double similarity(const StringSet& set1, const StringSet& set2)
{
    StringSet simLeftRight = set1 * set2;

    return simLeftRight.size()/(sqrt(set1.size())* sqrt(set2.size()));
}
